# babatundeogunlade.com

Official website of Hon. Babatunde Sunday Ogunlade (Ibarapa East, Oyo State).
Static site hosted on Cloudflare Pages from the `main` branch.

## Cloudflare Pages settings
- Framework preset: None
- Build command: (leave empty)
- Build output directory: `/`
- Production branch: `main`
- Custom domain: `babatundeogunlade.com` (www redirects to apex via `_redirects`)

## Conventions
- Root-relative paths (`/styles.css`, `/about`); extensionless page URLs.
- Canonical and Open Graph URLs always use `https://babatundeogunlade.com`.
- Filenames: lowercase, hyphen-separated, no spaces.
- Contact form: Web3Forms. Replace `YOUR_WEB3FORMS_ACCESS_KEY` in `contact.html`.

## Deploy
Commit to `main`; Cloudflare Pages deploys automatically. Use a branch for preview deployments.
